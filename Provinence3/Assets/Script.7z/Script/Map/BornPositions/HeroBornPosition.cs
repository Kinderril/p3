﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


public class HeroBornPosition : BaseBornPosition
{
    private bool isPositionOpend;
    public GameObject OpenGameObject;

    public void Init(Map map,bool isOpen)
    {
        base.Init(map);
        isPositionOpend = isOpen;
        if (OpenGameObject != null)
        {
            OpenGameObject.gameObject.SetActive(isPositionOpend);
        }

    }

    void OnTriggerEnter(Collider other)
    {
        if (!isPositionOpend)
        {
            var unit = other.GetComponent<Hero>();
            if (unit != null)
            {
                MainController.Instance.PlayerData.OpenBornPosition(ID);
                MainController.Instance.level.BigMessageAppear( "Born point opened", "",Color.blue);
                isPositionOpend = true;
                if (OpenGameObject != null)
                {
                    OpenGameObject.gameObject.SetActive(isPositionOpend);
                }
            }
        }
    }
    public override BornPositionType GetBornPositionType()
    {
        return BornPositionType.hero;
    }
}

