﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class Energy
{
    public const float TOTAl_AV_TIME = 60 * 7;
    public const float MAX_ENERGY = 60 * 3;
    public const float CREEP_ENERGY_AV = (TOTAl_AV_TIME - MAX_ENERGY) / Formuls.av_mosters_kills;
    public const int MAGIC_WEAPON_COST = (int)(CREEP_ENERGY_AV * 0.9f);
    public const float BONUS_ADD_ENERGY = MAX_ENERGY/4;

    private float powerLeft;
    private float maxpower = MAX_ENERGY; // 3min;
    //talisman cosnt = creep*cost(t)

    public Action<float, float> OnLeft;
    private Action<ItemId, int> activaAction;
    private float speedEnergyFall = 1f;
//    public event Action OnRage;
//    private bool isRageActivated = false;
    private Action<int> onActionHealth;


    public Energy(Action<ItemId, int> activaAction,Action<int> onActionHealth)
    {
        this.activaAction = activaAction;
        this.onActionHealth = onActionHealth;
//        this.OnRage += OnRage;
    }

    public float SpeedEnergyFallCoef
    {
        set { speedEnergyFall = value; }
    }

    public void Add(int value)
    {
        var powerLeft2 = Mathf.Clamp(powerLeft + value, 0, maxpower*2);
        if (powerLeft2 > maxpower)
        {
            powerLeft = maxpower;
            onActionHealth(Mathf.Abs((int)(powerLeft2-maxpower)));
        }
        else
        {
            powerLeft = powerLeft2;
        }
        ActionPOwerLeft();
        activaAction(ItemId.energy, value);
    }
    private void ActionPOwerLeft()
    {
        if (OnLeft != null)
        {
            OnLeft(powerLeft, maxpower);
        }
//        if (!isRageActivated)
//        {
//
//            if (powerLeft > maxpower)
//            {
//                if (OnRage != null)
//                {
//                    OnRage();
//                }
//                isRageActivated = true;
//            }
//        }
    }

    public void Dispose()
    {
//        OnRage = null;
    }

    public void Update()
    {
        powerLeft += Time.deltaTime* speedEnergyFall;
        ActionPOwerLeft();
    }
}

