﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class PostProcessingController : Singleton<PostProcessingController>
{
    public void StartFadeIn()
    {
        
    }

    public void EndFade()
    {
        
    }
}
